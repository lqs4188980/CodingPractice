package com.thumbtack.challenge.database;

public class DatabaseChallenge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DatabaseEngine engine = DatabaseEngine.getInstance();
		engine.commandReader();
	}

}
